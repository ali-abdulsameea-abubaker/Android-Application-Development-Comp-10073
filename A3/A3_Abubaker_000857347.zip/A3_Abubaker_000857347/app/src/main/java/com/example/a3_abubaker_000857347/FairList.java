package com.example.a3_abubaker_000857347;

import java.util.ArrayList;

/**
 *  I, Ali Abubaker,000857347 certify that this material is my original work. No other person's work has been used without due acknowledgement .
 * Extends ArrayList to hold a list of Projects for GSON parsing
 */
public class FairList extends ArrayList<Project> {
}