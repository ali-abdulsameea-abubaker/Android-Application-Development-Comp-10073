

/**
 * I, Ali_Abubaker  -000857347 certify that this material is my original
 * work. No other persons work has been used without due acknowledgment.
 * Date: 2025-02-06
 *user can put the input of the value from canadian dolors and converted to the specific currency.
 */
package com.example.a1_abubaker_000857347;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    /** PREFS_NAME: this is for perfernces Name
     * KEY_CURRENCY: storing user selected currency
     * KEY_RATE: storing rate
     * KEY_SELECTED_FLAG: user storing flag
     *DEFAULT_CURRENCY: default des currency
     * */
    private static final String PREFS_NAME = "CurrencyPrefs",
            KEY_CURRENCY = "selectedCurrency", KEY_RATE = "conversionRate",
            KEY_SELECTED_FLAG = "selectedFlag", DEFAULT_CURRENCY = "USD";
    /** convertButton getting button
     * configureButton: getting configure button
     * */
    private Button convertButton, configureButton;
    /** sourceFlag:  store our canadian flag
     * destinationFlag: store dest flag
     * */
    private ImageView sourceFlag,destinationFlag;
    /** default rate for des usd*/
    private static final float DEFAULT_RATE = 1.0f;
    /** textbox of result*/
    private TextView conversionResult;
    /** getting input*/
    private EditText inputAmount;
    /** selected currency */
    String selectedCurrency;
    /**conversionRate: updating rate for selected currency originalRate: Orignal rate*/
    private float conversionRate,originalRate;
    /**updating flag for selected flag*/
    private int selectedFlag;
    /**This onCreate method to start the main activity and showing all default values.*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeUI();
        loadPreferences(true);
        updateUI(false);
    }
    /** initialize UI (buttons, flags, inputs) for intraction */
    private void initializeUI() {
        Button helpButton = findViewById(R.id.helpButton);
        helpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHelpActivity();
            }
        });
        sourceFlag = findViewById(R.id.nationalSourceFlag);
        destinationFlag = findViewById(R.id.destinationCurrenciesFlag);
        inputAmount = findViewById(R.id.posativeDecimalNumberInput);
        convertButton = findViewById(R.id.conversionRateValue);
        conversionResult = findViewById(R.id.resultView);
        configureButton = findViewById(R.id.reconfigureButton);
        configureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettingsAndCreateShortcut();
            }
        });
        Switch directionSwitch = findViewById(R.id.directionSwitch);
        directionSwitch.setChecked(false);
        directionSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateConversionRate(isChecked);
            }
        });
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertCurrency();
            }
        });
    }
    /**open help activity*/
    private void openHelpActivity() {
        Intent intent = new Intent(MainActivity.this, HelpActivity.class);
        startActivity(intent);
    }
/**open setting and gives the option to create a short app on app home*/
    private void openSettingsAndCreateShortcut() {
        openSettings();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            createAppAction();
        }
    }
    /**update the rate when the user change the reate*/
    private void updateConversionRate(boolean isChecked) {
        if (isChecked) {
            conversionRate = 1 / originalRate;
            updateUI(true);
        } else {
            conversionRate = originalRate;
            updateUI(false);
        }
    }
    /**this method helps the app to create a short cut for the app on app menu when the user click ReconFigure
     * chatgpt helps me to build this part - source -
     * */
    @RequiresApi(api = Build.VERSION_CODES.N_MR1)
    private void createAppAction() {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("myapp://details/123"));
        ShortcutManager shortcutManager = getSystemService(ShortcutManager.class);
        ShortcutInfo shortcut = new ShortcutInfo.Builder(this, "getThing")
                .setShortLabel("Get Thing")
                .setLongLabel("Open my thing details")
                .setIcon(Icon.createWithResource(this, R.drawable.question)) // Set your icon here
                .setIntent(intent)
                .build();
        if (shortcutManager != null) {
            shortcutManager.requestPinShortcut(shortcut, null);
        }
        Toast.makeText(this, "Action created successfully", Toast.LENGTH_SHORT).show();
    }
    /**Loading the setting and selecting all user selections*/
    private void loadPreferences(boolean resetRate) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        selectedCurrency = prefs.getString(KEY_CURRENCY, DEFAULT_CURRENCY);
        selectedFlag = prefs.getInt(KEY_SELECTED_FLAG, R.drawable.usa);
        if (resetRate) {
            originalRate = prefs.getFloat(KEY_RATE, DEFAULT_RATE);
            conversionRate = originalRate; // Ensure correct initial rate
        }
        destinationFlag.setImageResource(selectedFlag);
    }
    /** Update UI with all user selections*/
    private void updateUI(boolean isCadToForeign) {
        inputAmount.setText("1.0");
        convertButton.setText(String.format("@%.2f=", conversionRate));// More precision for accuracy
        conversionResult.setText(String.format("%.2f", 1.0 * conversionRate));

        if (isCadToForeign) {
            sourceFlag.setImageResource(selectedFlag);
            destinationFlag.setImageResource(R.drawable.can);
        } else {
            sourceFlag.setImageResource(R.drawable.can);
            destinationFlag.setImageResource(selectedFlag);
        }
    }
    /** covert the currency base on user selection*/
    private void convertCurrency() {
        String inputText = inputAmount.getText().toString();
        double amount;
        try {
            amount = Double.parseDouble(inputText);
            if(amount>0){
                conversionResult.setText(String.format("%.2f", amount * conversionRate));
            } else {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            inputAmount.setText("1.0");
            inputAmount.setError("Invalid input! Defaulted to 1.0");
        }
    }
    /**open setting inside main activity 2*/
    private void openSettings() {
        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        startActivityForResult(intent, 1);
    }
    /** handling the result of selection from main activity 2*/
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            loadPreferences(true);
            Switch directionSwitch = findViewById(R.id.directionSwitch);
            directionSwitch.setChecked(false);
            sourceFlag.setImageResource(R.drawable.can);
            updateUI(false);
        }
    }
}
