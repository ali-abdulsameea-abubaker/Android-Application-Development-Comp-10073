

/**
 * I, Ali_Abubaker  -000857347 certify that this material is my original
 * work. No other persons work has been used without due acknowledgment.
 * Date: 2025-02-06
 *
 * this class is just simple class to show some info about the app
 */
package com.example.a1_abubaker_000857347;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class HelpActivity extends AppCompatActivity {
    /**when the app lunch, it will call textview and show the info*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        TextView helpText = findViewById(R.id.helpTextView);
        helpText.setText("This app converts CAD to various currencies.\n" +
                " Features include: \n" +
                "1- Configurable conversion rates \n" +
                "2- Bi-directional conversion \n" +
                "3- Additional 15+ currencies\n" +
                "Contact info: 000857347@mohawkcollege.ca");
    }
    /**it is the button to return to menu*/
    public void ReturnButton(View view){
        Intent returnToMain = new Intent(HelpActivity.this, MainActivity.class);
        startActivity(returnToMain);
    }


}