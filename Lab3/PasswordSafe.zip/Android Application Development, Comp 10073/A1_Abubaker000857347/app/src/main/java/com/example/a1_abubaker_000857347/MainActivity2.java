

/**
 * Currency Converter Activity main 2
 *
 * I, Ali_Abubaker  -000857347 certify that this material is my original
 * work. No other persons work has been used without due acknowledgment.
 * Date: 2025-02-06
 *
 * This class has been used for setting page and the
 * user can choice the currency for converting from Canadian dolors.
 */
package com.example.a1_abubaker_000857347;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity2 extends AppCompatActivity {
    /** PREFS_NAME: storing prefsences name
     * KEY_CURRENCY: storing selected currency
     *KEY_RATE: rate of the specific currency
     * KEY_SELECTED_FLAG: selected flag storing
     * KEY_SELECTED_FLAG:selected flag storing*/
    private static final String PREFS_NAME = "CurrencyPrefs",KEY_CURRENCY = "selectedCurrency",
            KEY_RATE = "conversionRate",KEY_SELECTED_FLAG = "selectedFlag";
    /**getting the list of currency*/
    private Spinner currencySpinner;
    /**adding textview of the rate*/
    private TextView conversionRateView;
    /**button to save the changes*/
    private Button saveButton;
    /**updating new flag selection*/
    private ImageView flagImageView;

    /** Selected currency. */
    private String selectedCurrency;
    /**selected rate*/
    private float conversionRate;
    /**selected flag*/
    private int selectedFlag;

    /**list all currency on spinner*/
    private final String[] currencies = {
            "US Dollar", "EURO", "British Pound", "Japanese Yen", "Indian Rupee",
            "Australian Dollar", "Swiss Franc", "Chinese Yuan", "Mexican Peso", "Brazilian Real",
            "South Korean Won", "South African Rand", "Russian Ruble", "Indonesian rupiah", "Saudi Riyal"
    };
    /**storing ratefor each one*/
    private final float[] conversionRates = {
            1.0f, 0.85f, 0.75f, 110.0f, 60.8f,
            1.3f, 0.92f, 6.4f, 20.2f, 5.3f,
            1185.0f, 14.8f, 74.5f, 11403.81f, 3.75f
    };
    /**storiing flag for each one*/
    private final int[] flags = {
            R.drawable.usa, R.drawable.eur, R.drawable.gbp, R.drawable.jpy, R.drawable.inr,
            R.drawable.aud, R.drawable.chf, R.drawable.cny, R.drawable.mxn, R.drawable.brl,
            R.drawable.krw, R.drawable.zar, R.drawable.rub, R.drawable.indo, R.drawable.sar
    };
    /**this is the main method when setting is displaying
     * it will show a default selection.
     * */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        currencySpinner = findViewById(R.id.spinnerOption);
        conversionRateView = findViewById(R.id.showingConversionRateValue);
        saveButton = findViewById(R.id.SaveButton);
        flagImageView = findViewById(R.id.flagImageView);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, currencies);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        currencySpinner.setAdapter(adapter);
        loadPreferences();
        currencySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedCurrency = currencies[position];
                conversionRate = conversionRates[position];
                selectedFlag = flags[position];
                conversionRateView.setText(String.format("%.2f", conversionRate));
                flagImageView.setImageResource(selectedFlag);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savePreferences();
            }
        });
        EditText customRateInput = findViewById(R.id.customRateInput);
        saveButton.setOnClickListener(v -> {
            String inputRate = customRateInput.getText().toString();
            if (!inputRate.isEmpty()) {
                try {
                    conversionRate = Float.parseFloat(inputRate);
                    if (conversionRate <= 0) {
                        conversionRate = 1.0f; // Set to default if rate is invalid or zero
                    }
                } catch (NumberFormatException e) {
                    conversionRate = 1.0f; // Fallback to default if parsing fails
                }
            }
            savePreferences();
        });
    }
    /** Loads stored preferences and updates UI. */
    private void loadPreferences() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        selectedCurrency = prefs.getString(KEY_CURRENCY, "USD");
        conversionRate = prefs.getFloat(KEY_RATE, 1.0f);
        selectedFlag = prefs.getInt(KEY_SELECTED_FLAG, R.drawable.usa);

        int index = 0;
        for (int i = 0; i < currencies.length; i++) {
            if (currencies[i].equals(selectedCurrency)) {
                index = i;
                break;
            }
        }
        currencySpinner.setSelection(index);
        conversionRateView.setText(String.format("%.2f", conversionRate));
        flagImageView.setImageResource(selectedFlag);
    }
    /** Saves selected currency preferences and returns to main activity. */
    private void savePreferences() {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
        editor.putString(KEY_CURRENCY, selectedCurrency);
        editor.putFloat(KEY_RATE, conversionRate);
        editor.putInt(KEY_SELECTED_FLAG, selectedFlag);
        editor.apply();
        Intent resultIntent = new Intent();
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}